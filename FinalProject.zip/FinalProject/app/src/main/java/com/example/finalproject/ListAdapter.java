package com.example.finalproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;

public class ListAdapter extends BaseAdapter{
    Context context;
    ArrayList<Beer> beerArrayList;
    LayoutInflater inflater;
    private View.OnClickListener itemlistner;
    public ListAdapter(Context context, ArrayList<Beer> beerArrayList){
        this.context=context;
        this.beerArrayList=beerArrayList;
    }
    @Override
    public int getCount()
    {
        return beerArrayList.size();
    }

    @Override
    public Object getItem(int position)
    {
        return beerArrayList.get(position);
    }

    @Override
    public long getItemId(int position)
    {
        return position;
    }
public  void  setOnItemClickListener(View.OnClickListener itemlistener)
{
    this.itemlistner=itemlistener;
}
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(inflater==null)
        {
            inflater=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        }
        if(convertView==null)
        {
            convertView =inflater.inflate(R.layout.customview,parent,false);
        }
        ImageView bimgv= convertView.findViewById(R.id.b_imgv);

        TextView textView= convertView.findViewById(R.id.textview);

        Picasso.get().load(beerArrayList.get(position).getImage()).into (bimgv);
        textView.setText(beerArrayList.get(position).getName());

        return convertView;
    }
}
